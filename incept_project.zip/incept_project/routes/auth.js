const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const auth = require('../middleware/auth'); 
const User = require('../models/User');

// routes/auth.js

router.post('/register', async (req, res) => {
    try {
        const { name, email, password } = req.body;

        // 1. Simple Validation Logic
        const hasUpper = /[A-Z]/.test(password);
        const hasLower = /[a-z]/.test(password);
        const hasNumber = /[0-9]/.test(password);
        // This is the key: it checks if there is ANY character that isn't a letter or number
        const hasSymbol = /[^A-Za-z0-9]/.test(password); 

        if (!email.includes('@')) return res.status(400).json({ msg: "Invalid email" });

        if (password.length < 8 || !hasUpper || !hasLower || !hasNumber || !hasSymbol) {
            return res.status(400).json({ msg: "Password too weak: Need 8+ chars, Upper, Lower, Num, and Symbol." });
        }

        // 2. Check existence
        let user = await User.findOne({ email });
        if (user) return res.status(400).json({ msg: "User already exists" });

        // 3. Save User
        user = new User({ name, email, password });
        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(password, salt);
        await user.save();

        const payload = { user: { id: user.id } };
        jwt.sign(payload, process.env.JWT_SECRET || 'your_secret', { expiresIn: '24h' }, (err, token) => {
            if (err) throw err;
            res.json({ token, user: { name, email } });
        });
    } catch (err) {
        res.status(500).send("Server Error");
    }
});

router.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        let user = await User.findOne({ email });
        if (!user) return res.status(400).json({ msg: 'Invalid Credentials' });
        
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(400).json({ msg: 'Invalid Credentials' });

        const payload = { user: { id: user.id } };
        jwt.sign(payload, process.env.JWT_SECRET || 'your_jwt_secret', { expiresIn: '24h' }, (err, token) => {
            if (err) throw err;
            res.json({ token, user: { name: user.name, email: user.email } });
        });
    } catch (err) {
        res.status(500).send('Server Error');
    }
});

module.exports = router;