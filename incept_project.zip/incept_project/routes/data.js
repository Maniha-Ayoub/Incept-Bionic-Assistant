const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User'); 

// Middleware to verify the user
const auth = (req, res, next) => {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) return res.status(401).json({ msg: 'No token, access denied' });
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your_jwt_secret');
        req.user = decoded.user;
        next();
    } catch (err) {
        res.status(401).json({ msg: 'Invalid Token' });
    }
};

// GET: Pulls memories
router.get('/history', auth, async (req, res) => {
    try {
        const user = await User.findById(req.user.id);
        if (!user) return res.status(404).json({ msg: "User not found" });
        res.json(user.saveSummaries || []);
    } catch (err) {
        res.status(500).json({ msg: "Server Error" });
    }
});

// POST: Saves memory to Atlas (FIXED: Added Timestamp)
router.post('/history', auth, async (req, res) => {
    try {
        const { title, transcript, content } = req.body;
        const user = await User.findById(req.user.id);
        
        // We add the timestamp here so it is saved in the database
        user.saveSummaries.unshift({ 
            title, 
            transcript, 
            content, 
            timestamp: new Date() 
        });
        await user.save();
        
        res.json(user.saveSummaries);
    } catch (err) {
        res.status(500).json({ msg: "Sync Failed" });
    }
});

// DELETE: Remove a single memory by ID (FIXED: Robust Filtering)
router.delete('/history/:id', auth, async (req, res) => {
    try {
        const user = await User.findById(req.user.id);
        if (!user) return res.status(404).json({ msg: "User not found" });

        // Match against both the MongoDB _id AND the timestamp string for safety
        user.saveSummaries = user.saveSummaries.filter(
            (item) => item._id.toString() !== req.params.id && String(item.timestamp) !== req.params.id
        );

        await user.save();
        res.json({ msg: "Memory purged from Atlas" });
    } catch (err) {
        res.status(500).json({ msg: "Delete Failed" });
    }
});

// DELETE: Clear all memories
router.delete('/history', auth, async (req, res) => {
    try {
        const user = await User.findById(req.user.id);
        user.saveSummaries = [];
        await user.save();
        res.json({ msg: "Neural Core Wiped" });
    } catch (err) {
        res.status(500).json({ msg: "Wipe Failed" });
    }
});

module.exports = router;