require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose'); 
const cors = require('cors');
const path = require('path');

const app = express();

// 1. DATABASE CONNECTION SWITCH
const dbURI = process.env.MONGO_URI || "mongodb://localhost:27017/inceptDB";

mongoose.connect(dbURI)
    .then(() => console.log(`Connected to: ${process.env.MONGO_URI ? 'MongoDB Atlas (Cloud)' : 'Local MongoDB'}`))
    .catch(err => console.error("Database connection error:", err));

// 2. MIDDLEWARE
app.use(express.json());
app.use(cors());

// 3. STATIC FILES (CSS, JS, Images)
app.use(express.static(path.join(__dirname, 'public')));

// 4. API ROUTES
app.use('/api/auth', require('./routes/auth'));
app.use('/api/data', require('./routes/data'));

// 5. THE "NOT FOUND" & FRONTEND ROUTING
app.get('/auth.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'auth.html'));
});

app.use((req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// IMPORTANT: PORT must be handled this way for Vercel
const PORT = process.env.PORT || 5000;
if (process.env.NODE_ENV !== 'production') {
    app.listen(PORT, () => {
        console.log(`Incept Server active`);
        console.log(`Local Link: http://localhost:${PORT}`); // This becomes clickable in VS Code
    });
}

// THE MISSING PIECE: Export for Vercel
module.exports = app;