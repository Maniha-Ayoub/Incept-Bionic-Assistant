const { GoogleGenerativeAI } = require("@google/generative-ai");

// Array of API keys
const apiKeys = [
    process.env.GEMINI_API_KEY, 
    process.env.GEMINI_API_KEY_BACKUP
];
let currentKeyIndex = 0;
let isSystemInCooldown = false;

/**
 * Helper function to create a delay
 */
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const summarizeTranscript = async (text) => {
    // If system hit a hard limit recently, block immediate retries
    if (isSystemInCooldown) {
        console.warn("Neural Link: System is in safety cooldown. Please wait...");
        return "QUOTA_EXCEEDED";
    }

    const modelsToTry = [
        "gemini-1.5-flash", 
        "gemini-2.0-flash",
        "gemini-1.5-flash-8b"
    ];

    for (const modelId of modelsToTry) {
        // Try each available key for the current model
        for (let i = 0; i < apiKeys.length; i++) {
            const activeKey = apiKeys[currentKeyIndex % apiKeys.length];
            const genAI = new GoogleGenerativeAI(activeKey);
            
            try {
                console.log(`Neural Link: Syncing with ${modelId} using Key_${currentKeyIndex % apiKeys.length}...`);
                const model = genAI.getGenerativeModel({ model: modelId });

                const prompt = `Summarize this bionic log into 3 clear bullet points: ${text}`;

                // Set a timeout for the request so it doesn't hang
                const result = await model.generateContent(prompt);
                const response = await result.response;
                const output = response.text();

                if (output) {
                    console.log(`Link Established: ${modelId} active.`);
                    return output;
                }
            } catch (err) {
                currentKeyIndex++; // Move to next key on failure
                
                if (err.message.includes("429") || err.message.includes("Quota")) {
                    console.error(`Quota Hit for ${modelId}. Pausing for 2 seconds before rotation...`);
                    await sleep(2000); // Small delay to let the API "breathe"
                    continue; 
                }
                console.warn(`Link Failed: ${modelId} - ${err.message.substring(0, 50)}`);
            }
        }
    }

    // If we reach here, all keys and models failed
    console.error("Critical: All Neural Link endpoints offline. Entering 60s Cooldown.");
    triggerCooldown();
    return "QUOTA_EXCEEDED";
};

// Prevents spamming the API for 60 seconds if everything is exhausted
function triggerCooldown() {
    isSystemInCooldown = true;
    setTimeout(() => {
        isSystemInCooldown = false;
        console.log("Neural Link: Safety cooldown lifted. Ready for re-sync.");
    }, 60000); 
}

module.exports = { summarizeTranscript };