const mongoose = require('mongoose');

// Creating a sub-schema makes it easier to manage memory entries
const MemorySchema = new mongoose.Schema({
    title: String,
    transcript: String, // Added this to match your saveToHistory sync
    content: String,    // This stores the summary
    date: { type: Date, default: Date.now }
});

const UserSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    accessibilityMode: { 
        type: String, 
        enum: ['Deaf-Assist', 'Blind-Assist', 'Cognitive-Ease', 'Standard', 'Universal'],
        default: 'Universal'
    },
    // Use the sub-schema here
    saveSummaries: [MemorySchema]
});

module.exports = mongoose.model('User', UserSchema);