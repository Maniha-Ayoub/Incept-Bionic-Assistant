let isLogin = false;

// 1. Password Visibility Toggle
window.togglePasswordVisibility = function() {
    const passwordInput = document.getElementById('password');
    const eyeIcon = document.getElementById('eyeIcon');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        eyeIcon.setAttribute('data-lucide', 'eye-off');
    } else {
        passwordInput.type = 'password';
        eyeIcon.setAttribute('data-lucide', 'eye');
    }
    if (window.lucide) lucide.createIcons();
};

// 2. Auth Mode Toggle
window.toggleAuth = function() {
    isLogin = !isLogin;
    document.getElementById('formTitle').innerText = isLogin ? "INCEPT LOGIN" : "INCEPT SIGNUP";
    document.getElementById('name').style.display = isLogin ? 'none' : 'block';
    document.getElementById('name').required = !isLogin;
    document.getElementById('submitBtn').innerText = isLogin ? "Sign In" : "Initialize Incept";
    document.getElementById('toggleLink').innerText = isLogin ? "New here? Create Account" : "Already have an account? Sign In";
    document.getElementById('message').innerText = "";
};

document.addEventListener('DOMContentLoaded', () => {
    const authForm = document.getElementById('authForm');
    
    authForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const msg = document.getElementById('message');
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value;
        const nameVal = document.getElementById('name').value;

        // NEW LOGIC: Individual checks instead of regex to support all symbols
        const hasUpper = /[A-Z]/.test(password);
        const hasLower = /[a-z]/.test(password);
        const hasNum = /[0-9]/.test(password);
        const hasSymbol = /[^A-Za-z0-9]/.test(password);
        const hasLength = password.length >= 8;

        if (!email.includes('@')) {
            msg.style.color = "#ff4444";
            msg.innerText = "Error: Invalid Email Format";
            return;
        }

        // Only check complexity on Signup
        if (!isLogin && !(hasUpper && hasLower && hasNum && hasSymbol && hasLength)) {
            msg.style.color = "#ff4444";
            msg.innerText = "Weak Password: Need Upper, Lower, Number & Symbol.";
            return;
        }

        msg.style.color = "#00d2ff";
        msg.innerText = "Authenticating...";

        try {
            const endpoint = isLogin ? '/api/auth/login' : '/api/auth/register';
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email,
                    password,
                    name: isLogin ? undefined : nameVal
                })
            });

            const data = await response.json();

            if (response.ok) {
                localStorage.setItem('token', data.token);
                // Save name for the dashboard
                const nameToSave = (data.user && data.user.name) ? data.user.name : nameVal;
                localStorage.setItem('userName', nameToSave || "Bionic User");
                window.location.href = 'dashboard.html';
            } else {
                msg.style.color = "#ff4444";
                msg.innerText = data.msg;
            }
        } catch (err) {
            msg.style.color = "#ff4444";
            msg.innerText = "Server Error: Connection Failed.";
        }
    });
});