(function protectRoute() {
    if (!localStorage.getItem('token')) { window.location.href = 'index.html'; }
})();

if (window.speechSynthesis) { window.speechSynthesis.cancel(); }

async function deleteMemory(id) {
    if (!confirm("Delete this memory?")) return;
    
    // 1. Remove from local storage immediately
    let localData = JSON.parse(localStorage.getItem('incept_memories') || "[]");
    const updatedData = localData.filter(item => {
        const memoryId = item._id || item.timestamp;
        return String(memoryId) !== String(id);
    });
    localStorage.setItem('incept_memories', JSON.stringify(updatedData));
    
    // Update screen immediately
    renderUI(updatedData); 

    // 2. Sync with Cloud
    try {
        await fetch(`/api/data/history/${id}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
        });
    } catch(err) { console.log("Cloud delete pending sync."); }
}

async function loadHistory() {
    const list = document.getElementById('historyList');
    if (!list) return;

    list.innerHTML = `<div style="text-align:center; padding: 40px; color: #00d2ff;"><i class="fas fa-sync fa-spin fa-2x"></i></div>`;

    try {
        const response = await fetch(`/api/data/history?t=${Date.now()}`, {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
        });
        if (response.ok) {
            const atlasData = await response.json();
            localStorage.setItem('incept_memories', JSON.stringify(atlasData));
            renderUI(atlasData);
            return;
        }
    } catch (e) { console.log("Offline mode."); }

    const localData = JSON.parse(localStorage.getItem('incept_memories') || "[]");
    renderUI(localData);
}

function renderUI(data) {
    const list = document.getElementById('historyList');
    if (!list) return;
    list.innerHTML = "";

    if (data.length === 0) {
        list.innerHTML = "<p style='color:#888; text-align:center;'>Neural Core Empty.</p>";
        return;
    }

    // Sort newest first
    data.sort((a, b) => {
        const dateA = new Date(a.timestamp || a.createdAt || Date.now());
        const dateB = new Date(b.timestamp || b.createdAt || Date.now());
        return dateB - dateA;
    });

    data.forEach((item, i) => {
        const card = document.createElement('div');
        card.className = "glass-panel history-card";
        card.style.marginBottom = "15px";
        
        const memoryId = item._id || item.timestamp;
        
        let timeDisplay = "Recently Saved";
        const rawDate = item.timestamp || item.createdAt || item.date;
        
        if (rawDate) {
            const d = new Date(rawDate);
            if (!isNaN(d.getTime())) {
                timeDisplay = d.toLocaleString();
            }
        }

        card.innerHTML = `
            <div class="card-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <strong style="color: #00d2ff; font-size: 0.9rem;"><i class="fas fa-microchip"></i> ${item.title || "Memory Entry"}</strong>
                <button class="btn-danger" onclick="deleteMemory('${memoryId}')" style="width: 30px; height: 30px; border-radius: 5px; border:none; color:white; cursor:pointer;">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
            <div style="color: #00d2ff; font-size: 0.7rem; margin-bottom: 10px; font-family: monospace;">${timeDisplay}</div>
            <div style="color: #fff; font-size: 0.85rem; line-height: 1.4; margin-bottom: 10px;">${item.content || ""}</div>
            <div id="text-${i}" style="color: #ccc; font-size: 0.8rem; background: rgba(0,0,0,0.2); padding: 8px; border-radius: 5px;">${item.transcript || ""}</div>
            
            <div style="display: flex; gap: 10px; margin-top: 10px;">
                <button class="btn-primary" onclick="readAloud(${i})" style="flex: 1; height: 35px; border:none; color:white; border-radius:5px; cursor:pointer;">
                    <i class="fas fa-volume-up"></i> Read Memory
                </button>
                <button class="btn-danger" title="Stop Reading" onclick="window.speechSynthesis.cancel()" style="width: 45px; height: 35px; border-radius: 5px; border:none; color:white; cursor:pointer; background: rgba(255, 68, 68, 0.4);">
                    <i class="fas fa-stop"></i>
                </button>
            </div>`;
        list.appendChild(card);
    });
}

async function clearAllHistory() {
    if (!confirm("Wipe ALL memories from storage? This cannot be undone.")) return;
    localStorage.setItem('incept_memories', JSON.stringify([]));
    try {
        await fetch('/api/data/history', {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
        });
    } catch(err) { console.log("Wipe failed."); }
    loadHistory();
}

function readAloud(i) {
    const text = document.getElementById(`text-${i}`)?.innerText;
    if (!text) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'hi-IN';
    utterance.rate = 0.9;
    utterance.pitch = 1.1;
    window.speechSynthesis.speak(utterance);
}

document.addEventListener('DOMContentLoaded', loadHistory);