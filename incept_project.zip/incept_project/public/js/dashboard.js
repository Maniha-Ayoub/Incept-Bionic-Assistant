// 1. Global variables
let currentFacingMode = "environment";
let track = null;
let activeStream = null;
let visionInterval = null;
let isListening = false;
let activeRecognition = null;
let isDashboardLogin = true;
let lastDetectedObject = ""; // TRACKER: Prevents repeating the same object name

const DEV_MODE = false;

// EMERGENCY RESET: Stops any ghost voices on load
if (window.speechSynthesis) { window.speechSynthesis.cancel(); }

/** 2. INITIALIZATION LOGIC **/

// js/dashboard.js

function initDashboard() {
    console.log("Neural Link: Dashboard Initialized.");
    
    let name = localStorage.getItem('userName');
    let email = localStorage.getItem('userEmail'); // Added email retrieval
    
    if (!name) {
        name = "User";
    }

    const navName = document.getElementById('userName'); 
    if (navName) {
        navName.innerText = name;
    }

    const navEmail = document.getElementById('userEmail'); 
    if (navEmail) {
        navEmail.innerText = email || "";
    }

    const greeting = document.getElementById('userGreeting');
    if (greeting) {
        greeting.innerText = `Welcome, ${name.split(' ')[0]}`;
    }

    applyBionicHoverEffects();
}
// Remove syncWithAtlas() as it contains fetch calls that reset your data
function applyBionicHoverEffects() {
    const actionButtons = document.querySelectorAll('.btn-primary, .btn-secondary, #actionBtn, #summarizeBtn');
    actionButtons.forEach(btn => {
        btn.style.transition = "all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)";
        btn.onmouseover = () => {
            btn.style.transform = "scale(1.05)";
            btn.style.boxShadow = "0 0 15px #00d2ff";
            btn.style.filter = "brightness(1.2)";
        };
        btn.onmouseout = () => {
            btn.style.transform = "scale(1)";
            btn.style.boxShadow = "none";
            btn.style.filter = "brightness(1)";
        };
    });
}

function triggerBionicVibration(pattern = 150) {
    if ("vibrate" in navigator) {
        try { navigator.vibrate(pattern); } catch (e) { console.log("Vibration blocked."); }
    }
}

/** 3. VISION MODULE **/
async function loadVisionModule() {
    const display = document.getElementById('displayArea');
    const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
    display.innerHTML = `
        <div style="display: flex; flex-direction: column; align-items: center; position: relative;">
            <video id="webcam" autoplay muted playsinline style="width: 100%; max-width: 500px; border-radius: 15px; border: 2px solid #00d2ff;"></video>
            ${isMobile ? `
            <div style="display: flex; gap: 10px; margin-top: 15px;">
                <button onclick="switchCamera()" class="btn-primary" style="padding: 12px 20px;"><i class="fas fa-sync"></i> Flip</button>
                <button onclick="toggleTorch()" id="torchBtn" class="btn-primary" style="padding: 12px 20px;"><i class="fas fa-lightbulb"></i> Flash</button>
            </div>
            <div style="width: 85%; max-width: 400px; margin-top: 20px;">
                <label style="color: #00d2ff; font-size: 0.8rem;">ZOOM MAGNIFICATION</label>
                <input type="range" id="zoomRange" min="1" max="3" step="0.1" value="1" style="width: 100%; accent-color: #00d2ff;">
            </div>` : ''}
            <div id="visionLogs" style="margin-top: 20px; color: #00d2ff; font-weight: bold;">AI LENS: CALIBRATING...</div>
        </div>`;
    
    await startCamera(currentFacingMode);

    // Zoom hardware link
    const zoomInput = document.getElementById('zoomRange');
    if(zoomInput) {
        zoomInput.addEventListener('input', async (e) => {
            if (track && track.getCapabilities().zoom) {
                try { await track.applyConstraints({ advanced: [{ zoom: e.target.value }] }); } catch(err) { console.log(err); }
            }
        });
    }
}

async function startCamera(mode) {
    if (activeStream) { activeStream.getTracks().forEach(t => t.stop()); }
    try {
        activeStream = await navigator.mediaDevices.getUserMedia({ 
            video: { facingMode: mode, zoom: true } 
        });
        const videoElement = document.getElementById('webcam');
        if (videoElement) { videoElement.srcObject = activeStream; }
        track = activeStream.getVideoTracks()[0];

        if (typeof cocoSsd !== 'undefined') {
            const model = await cocoSsd.load();
            if (visionInterval) clearInterval(visionInterval);
            visionInterval = setInterval(async () => {
                if (activeStream && activeStream.active && videoElement && videoElement.readyState === 4) {
                    const predictions = await model.detect(videoElement);
                    if (predictions.length > 0) {
                        const item = predictions[0].class;
                        if (item !== lastDetectedObject) {
                            lastDetectedObject = item;
                            const logText = `DETECTED: ${item.toUpperCase()}`;
                            document.getElementById('visionLogs').innerText = logText;
                            triggerBionicVibration([150, 50, 150]);
                            window.speechSynthesis.cancel();
                            const textToSpeak = "I see " + item;
                            const utterance = new SpeechSynthesisUtterance(textToSpeak);
                            const hasUrdu = /[\u0600-\u06FF]/.test(textToSpeak);
                            if (hasUrdu) { utterance.lang = 'ur-PK'; utterance.rate = 0.85; } 
                            else { utterance.lang = 'en-US'; utterance.rate = 0.9; }
                            window.speechSynthesis.speak(utterance);
                        }
                    } else { lastDetectedObject = ""; }
                }
            }, 3000);
        }
    } catch (e) { console.error("Camera Error:", e); }
}

// Global functions for the buttons
window.switchCamera = async function() {
    currentFacingMode = (currentFacingMode === "user") ? "environment" : "user";
    await startCamera(currentFacingMode);
};

window.toggleTorch = async function() {
    if (track && track.getCapabilities().torch) {
        const currentTorch = track.getConstraints().advanced?.[0]?.torch || false;
        await track.applyConstraints({ advanced: [{ torch: !currentTorch }] });
    }
};

/** 4. SUMMARIZATION & SYNC LOGIC **/
function generateLocalSummary(text) {
    const lowerText = text.toLowerCase();
    let actionDetected = "General observation";
    if (lowerText.includes("karoge") || lowerText.includes("karo")) actionDetected = "Execution request detected (Karoge)";
    else if (lowerText.includes("lagana") || lowerText.includes("lagao")) actionDetected = "Attachment/Setup task (Lagana)";
    else if (lowerText.includes("i see") || lowerText.includes("detected")) actionDetected = "Visual identification logged";
    
    const words = lowerText.replace(/[^\w\s]/g, '').split(/\s+/);
    const stopWords = ['the', 'is', 'at', 'which', 'on', 'and', 'a', 'to', 'in', 'i', 'am', 'was', 'for', 'please', 'use'];
    const keywords = words.filter(word => word.length > 3 && !stopWords.includes(word));
    const uniqueKeywords = [...new Set(keywords)].slice(0, 5).map(w => w.toUpperCase());
    return `• ACTION: ${actionDetected}<br>• KEYWORDS: ${uniqueKeywords.join(', ') || 'NONE'}<br>• ANALYTICS: Neural Link processed successfully`;
}

async function saveAndSummarize() {
    const logs = document.getElementById('audioLogs');
    const summarizeBtn = document.getElementById('summarizeBtn');
    if (!logs || !summarizeBtn) return;
    const transcript = logs.innerText;
    if (!transcript || transcript.trim() === "" || transcript.includes("Waiting")) {
        alert("No data captured."); return;
    }
    summarizeBtn.disabled = true;
    summarizeBtn.innerHTML = '<i class="fas fa-microchip fa-spin"></i> ANALYZING...';
    setTimeout(async () => {
        const localSummary = generateLocalSummary(transcript);
        renderSummaryUI(localSummary, transcript);
        await saveToHistory(transcript, localSummary);
        triggerBionicVibration(200);
    }, 1200);
}

function renderSummaryUI(summaryHtml, originalTranscript) {
    const logs = document.getElementById('audioLogs');
    const summarizeBtn = document.getElementById('summarizeBtn');
    if(!logs) return;
    logs.innerHTML = `
        <div style="color: #888; font-size: 0.85rem; margin-bottom: 15px; font-style: italic;">"${originalTranscript}"</div>
        <div style="background: rgba(0,210,255,0.1); padding: 15px; border-radius: 10px; border-left: 3px solid #00d2ff;">
            <h3 style="color: #00d2ff; font-size: 0.9rem; margin-top: 0;"><i class="fas fa-microchip"></i> NEURAL SUMMARY</h3>
            <div style="color: #fff; line-height: 1.6;">${summaryHtml}</div>
        </div>`;
    summarizeBtn.innerHTML = '<i class="fas fa-history"></i> Access Memories';
    summarizeBtn.onclick = () => { window.speechSynthesis.cancel(); window.location.href = 'history.html'; };
    summarizeBtn.disabled = false;
}

async function saveToHistory(rawText, summary) {
    const cloudMemory = {
        title: rawText.includes("DETECTED:") ? "Vision Memory" : "Audio Memory",
        transcript: rawText,
        content: summary,
        timestamp: new Date().toISOString()
    };
    try {
        let localData = JSON.parse(localStorage.getItem('incept_memories') || "[]");
        localData.unshift({ ...cloudMemory, _id: "temp-" + Date.now() });
        localStorage.setItem('incept_memories', JSON.stringify(localData.slice(0, 50)));
    } catch (e) { console.error("Local Save Error:", e); }
    try {
        await fetch('/api/data/history', {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}`, 'Content-Type': 'application/json' },
            body: JSON.stringify(cloudMemory)
        });
    } catch (e) { console.warn("Atlas sync pending."); }
}

async function syncWithAtlas() {
    // Only pull from cloud if local storage is empty to avoid overwriting deletions
    let localData = JSON.parse(localStorage.getItem('incept_memories') || "[]");
    if (localData.length > 0) return; 

    try {
        const response = await fetch('/api/data/history', {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
        });
        if (response.ok) {
            const atlasData = await response.json();
            if (Array.isArray(atlasData)) {
                localStorage.setItem('incept_memories', JSON.stringify(atlasData));
            }
        }
    } catch (e) { console.log("Offline mode."); }
}

/** 5. AUDIO MODULE **/
function activateFeature(feature) {
    stopAllSensors();
    const display = document.getElementById('displayArea');
    display.innerHTML = "<p style='color:#00d2ff'>Initializing...</p>";
    if (feature === 'audio') loadAudioModule();
    else if (feature === 'vision') loadVisionModule();
}

function loadAudioModule() {
    const display = document.getElementById('displayArea');
    display.innerHTML = `<div id="audioLogs" style="background: rgba(0,0,0,0.3); padding: 20px; border-radius: 10px; min-height: 100px; color: #00d2ff;">Waiting for audio link...</div>`;
    document.getElementById('actionBtn').style.display = "block";
    document.getElementById('actionBtn').innerHTML = '<i class="fas fa-microphone"></i> Start Voice Link';
    document.getElementById('summarizeBtn').style.display = "none";
    applyBionicHoverEffects();
}

function toggleListening() { if (!isListening) startSpeechRecognition(); else stopSpeechRecognition(); }

function startSpeechRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return;
    const logArea = document.getElementById('audioLogs');
    activeRecognition = new SpeechRecognition();
    activeRecognition.continuous = true;
    activeRecognition.interimResults = true;
    activeRecognition.lang = 'en-IN'; 
    activeRecognition.onstart = () => {
        isListening = true;
        document.getElementById('actionBtn').innerHTML = '<i class="fas fa-stop"></i> Stop Link';
        document.getElementById('actionBtn').style.backgroundColor = "#ff4444";
    };
    activeRecognition.onresult = (event) => {
        const transcript = Array.from(event.results).map(r => r[0].transcript).join('');
        if(logArea) {
            logArea.innerText = transcript;
            if (transcript.trim().length > 5) document.getElementById('summarizeBtn').style.display = "block";
        }
    };
    activeRecognition.start();
}

function stopSpeechRecognition() {
    if (activeRecognition) { activeRecognition.stop(); isListening = false; }
    document.getElementById('actionBtn').style.backgroundColor = "";
    document.getElementById('actionBtn').innerHTML = '<i class="fas fa-microphone"></i> Start Voice Link';
}

function stopAllSensors() {
    if (activeRecognition) { activeRecognition.stop(); isListening = false; }
    if (activeStream) { activeStream.getTracks().forEach(t => t.stop()); activeStream = null; }
    if (visionInterval) clearInterval(visionInterval);
    window.speechSynthesis.cancel();
    lastDetectedObject = "";
    document.getElementById('actionBtn').style.display = "none";
    document.getElementById('summarizeBtn').style.display = "none";
}

function toggleSidebar() { document.getElementById('sideNav')?.classList.toggle('active'); }

function logout() {
    window.speechSynthesis.cancel();
    localStorage.removeItem('token');
    localStorage.removeItem('userName');
    window.location.href = 'index.html';
}

(function protectRoute() { if (!localStorage.getItem('token')) { window.location.href = 'index.html'; } })();

if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('sw.js').then(() => console.log("Shield Active."));
    });
}

document.addEventListener('DOMContentLoaded', initDashboard);