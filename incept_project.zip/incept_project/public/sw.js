const CACHE_NAME = 'incept-v1';
const assets = [
  '/',
  '/index.html',
  '/dashboard.html',
  '/history.html',
  '/css/style.css',
  '/js/auth.js',
  '/js/dashboard.js',
  '/js/history.js'
];

// Install Service Worker
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      console.log('Incept: Caching System Files');
      return cache.addAll(assets);
    })
  );
});

// Fetching from Cache
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request).then(response => {
      return response || fetch(event.request);
    })
  );
});